Developed in C# a desktop application Othello
game, with WinForms.
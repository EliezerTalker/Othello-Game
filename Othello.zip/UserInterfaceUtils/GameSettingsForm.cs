﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Ex05_Othelo;

namespace UserInterfaceUtils
{
    /*Please note that we would like this class to be internal but it does not allow us and that is why it has no class modifier - in additon the designer made the class without a modifier than the partial*/
    partial class GameSettingsForm : Form
    {
        private int m_CurrentBoardSize = 6;
        private eGameModes m_ChosenGameMode;

        public int CurrentBoardSize
        {
            get
            {
                return m_CurrentBoardSize;
            }
        }

        public eGameModes ChosenGameMode
        {
            get
            {
                return m_ChosenGameMode;
            }
        }

        public GameSettingsForm()
        {
            InitializeComponent();
        }

        /*This function is responsible to show on the forn the board size the can be choosen and it saves the choice*/
        private void buttonBoardSize_Click(object sender, EventArgs e)
        {
            const int k_MaxBoardSize = 12;
            const int k_MinBoardSize = 6;
            const int k_BoardSizeTen = 10;
            const int k_Two = 2;

            if (m_CurrentBoardSize == k_BoardSizeTen)
            {
                m_CurrentBoardSize = k_MaxBoardSize;
                buttonBoardSize.Text = "Board Size: 12x12 (click to set size to 6x6)";
            }
            else
            {
                m_CurrentBoardSize = m_CurrentBoardSize == k_MaxBoardSize ? k_MinBoardSize : m_CurrentBoardSize + k_Two;
                buttonBoardSize.Text = string.Format("Board Size: {0}x{0} (click to increase)", m_CurrentBoardSize);
            }
        }

        /*This function saves the users choice if he chose Player V.S PC*/
        private void buttonPlayerVSPc_Click(object sender, EventArgs e)
        {
            m_ChosenGameMode = eGameModes.HumanVsComputer;
            DialogResult = DialogResult.OK;
        }

        /*This function saves the users choice if he chose Player V.S Player*/
        private void buttonPlayerVsPlayer_Click(object sender, EventArgs e)
        {
            m_ChosenGameMode = eGameModes.HumanVsHuman;
            DialogResult = DialogResult.OK;
        }

        /*This function is responsible to show the setting form*/
        public void ShowGameSettingsForm()
        {
            this.ShowDialog();
        }
    }
}

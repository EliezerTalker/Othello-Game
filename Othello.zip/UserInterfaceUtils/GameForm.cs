﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Ex05_Othelo;

namespace UserInterfaceUtils
{
    /*Please note that we would like this class to be internal but it does not allow us and that is why it has no class modifier - in additon the designer made the class without a modifier than the partial*/
    public partial class GameForm : Form
    {
        private int m_AmountOfGreenButtons;
        private PictureBox[,] m_PictureBoxMatrix;
        private OthelloGame m_ourGame = new OthelloGame();
        private ePlayers m_CurrentPlayerPlaying = ePlayers.First;

        public GameForm()
        {
            InitializeComponent();        
        }

        /*This function builds the alloctes the pictureBoxMatrix and makes the Picturebox's*/
        private void buildPictureBoxMatrix(int i_SizeOfMatrix)
        {
            int formWidth;
            int formHeight;
            const int k_Thirty = 30;

            m_PictureBoxMatrix = new PictureBox[i_SizeOfMatrix, i_SizeOfMatrix];
            for (int i = 0; i < i_SizeOfMatrix; i++)
            {
                for (int j = 0; j < i_SizeOfMatrix; j++)
                {
                    m_PictureBoxMatrix[i, j] = createPictureBox(i, j);
                    m_PictureBoxMatrix[i, j].BorderStyle = BorderStyle.FixedSingle;
                    m_PictureBoxMatrix[i, j].Click += new EventHandler(pictureBox_Click);
                }
            }

            formWidth = (m_PictureBoxMatrix[i_SizeOfMatrix - 1, i_SizeOfMatrix - 1].Width * i_SizeOfMatrix) + k_Thirty;
            formHeight = (m_PictureBoxMatrix[i_SizeOfMatrix - 1, i_SizeOfMatrix - 1].Height * i_SizeOfMatrix) + k_Thirty;
            this.ClientSize = new System.Drawing.Size(formWidth, formHeight);
            putOthelloPictureBoxsOnForm();
        }

        /*This function is resposible to put the PictureBoxs on the form in a shape of a matrix*/
        private void putOthelloPictureBoxsOnForm()
        {
            int numberOfPictureBoxs = m_PictureBoxMatrix.GetLength(0);
            const int k_Fifthteen = 15;

            for (int i = 0; i < numberOfPictureBoxs; i++)
            {
                for (int j = 0; j < numberOfPictureBoxs; j++)
                {
                    m_PictureBoxMatrix[i, j].Left = k_Fifthteen + (j * m_PictureBoxMatrix[i, j].Width);
                    m_PictureBoxMatrix[i, j].Top = k_Fifthteen + (i * m_PictureBoxMatrix[i, j].Height);
                    this.Controls.Add(m_PictureBoxMatrix[i, j]);
                }
            }
        }

        /*This function is activated once a PictureBox is clicked and it is responsible the change the appearence of the board, based on the choosen move*/
        private void pictureBox_Click(object sender, EventArgs e)
        {
            m_ourGame.TurnOf = m_CurrentPlayerPlaying;
            this.pictureBoxToFlipBasedOnCurrentsPlayerMoveAndColor(sender as PictureBox);
            if (m_CurrentPlayerPlaying == ePlayers.First && m_ourGame.GameMode == eGameModes.HumanVsComputer)
            {
                Form.ActiveForm.Refresh();
                this.SuspendLayout();
                this.setPictureBoxMatrixForNextPlayer();
                Thread.Sleep(4000);
                this.ResumeLayout();
                Form.ActiveForm.Refresh();
                this.SuspendLayout();
                computersTurn();
                this.ResumeLayout();
            }

            this.setPictureBoxMatrixForNextPlayer();
            if (m_AmountOfGreenButtons == 0)
            {
                Thread.Sleep(2000);
                this.setPictureBoxMatrixForNextPlayer();
                if(m_AmountOfGreenButtons == 0)
                {
                    showResultAndAskIfNewRoundWanted();

                    return;
                }
            }
        }

        /*This function finds all of the legal moves for the current player and makes color of those moves green*/
        private void findGreenCellsAndMarkPictureBoxsGreen()
        {
            List<Cell> validMoves;
            int numOfValidMoves;

            validMoves = m_ourGame.GetCurrentsPlayerLegalMoves();
            numOfValidMoves = validMoves.Count;
            for (int i = 0; i < numOfValidMoves; i++)
            {
                m_PictureBoxMatrix[validMoves[i].XYCord.IndexOfRow, validMoves[i].XYCord.IndexOfCol].BackColor = Color.LimeGreen;
                m_PictureBoxMatrix[validMoves[i].XYCord.IndexOfRow, validMoves[i].XYCord.IndexOfCol].Enabled = true;
            }

            m_AmountOfGreenButtons = numOfValidMoves;
        }

        /*This function gets a choosen move as a PictureBox and returns which cells in the matrix should change their image*/
        private List<Cell> getCellsToFlipBasedOnClickedPictureBox(PictureBox i_PictureBox)
        {
            List<Cell> cellsToFlip = new List<Cell>();
            int rowsInBoard = m_PictureBoxMatrix.GetLength(0);
            int colsInBoard = m_PictureBoxMatrix.GetLength(1);

            for (int i = 0; i < rowsInBoard; i++)
            {
                for (int j = 0; j < colsInBoard; j++)
                {
                    if (m_PictureBoxMatrix[i, j] == i_PictureBox)
                    {
                        if(m_CurrentPlayerPlaying == ePlayers.Second && m_ourGame.GameMode == eGameModes.HumanVsComputer)
                        {
                            cellsToFlip = m_ourGame.GetCellsToFlipForCurrentMove(i, j);
                        }
                        else if (m_ourGame.PlayChosenPlayersTurnPlayerTurn(m_CurrentPlayerPlaying, i, j))
                        {
                            cellsToFlip = m_ourGame.GetCellsToFlipForCurrentMove(i, j);
                        }
                            
                        break;
                    }
                }
            }

            return cellsToFlip;
        }

        /*This function gets a choosen move as a PictureBox and changes the image of the PictureBoxs based on the given move*/
        private void pictureBoxToFlipBasedOnCurrentsPlayerMoveAndColor(PictureBox i_ChosenPictureBox)
        {
            List<Cell> cellsToFlip = this.getCellsToFlipBasedOnClickedPictureBox(i_ChosenPictureBox);
            int amountOfCells = cellsToFlip.Count;
            Image imageForPictureBox = m_CurrentPlayerPlaying == ePlayers.First ? Properties.Resources.CoinRed : Properties.Resources.CoinYellow;

            for (int i = 0; i < amountOfCells; i++)
            { 
                m_PictureBoxMatrix[cellsToFlip[i].XYCord.IndexOfRow, cellsToFlip[i].XYCord.IndexOfCol].Image = imageForPictureBox;
                m_PictureBoxMatrix[cellsToFlip[i].XYCord.IndexOfRow, cellsToFlip[i].XYCord.IndexOfCol].SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            }
        }

        /*This function finds all of PictureBoxs that are currently green and sets their background color to a default*/
        private void unMarkGreenPictureBoxs()
        {
            int pictureBoxMatrixRows = m_PictureBoxMatrix.GetLength(0);
            int pictureBoxMatrixColumns = m_PictureBoxMatrix.GetLength(1);

            for (int i = 0; i < pictureBoxMatrixRows; i++)
            {
                for (int j = 0; j < pictureBoxMatrixColumns; j++)
                {
                    if (m_PictureBoxMatrix[i, j].BackColor == Color.LimeGreen)
                    {
                        m_PictureBoxMatrix[i, j].BackColor = System.Drawing.SystemColors.Control;
                        m_PictureBoxMatrix[i, j].Enabled = false;
                    }
                }
            }
        }

        /*This function puts on the Board the image of the coins that need to be presented once a new game is started*/
        private void initializePictureBoxMatrix()
        {
            List<Cell> cellsToInitialize = new List<Cell>();
            int amountOfButtonToInitialize;

            setAllMatrixPictureBoxsToDisableAndControlColor();
            cellsToInitialize = m_ourGame.GetInitializePositionCells();
            amountOfButtonToInitialize = cellsToInitialize.Count;
            for (int i = 0; i < amountOfButtonToInitialize; i++)
            {
                if (cellsToInitialize[i].CellColor == eColor.Black)
                {
                    m_PictureBoxMatrix[cellsToInitialize[i].XYCord.IndexOfRow, cellsToInitialize[i].XYCord.IndexOfCol].Image = Properties.Resources.CoinRed;
                }
                else
                {
                    m_PictureBoxMatrix[cellsToInitialize[i].XYCord.IndexOfRow, cellsToInitialize[i].XYCord.IndexOfCol].Image = Properties.Resources.CoinYellow;
                }

                m_PictureBoxMatrix[cellsToInitialize[i].XYCord.IndexOfRow, cellsToInitialize[i].XYCord.IndexOfCol].SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
                m_PictureBoxMatrix[cellsToInitialize[i].XYCord.IndexOfRow, cellsToInitialize[i].XYCord.IndexOfCol].Visible = true;
                m_PictureBoxMatrix[cellsToInitialize[i].XYCord.IndexOfRow, cellsToInitialize[i].XYCord.IndexOfCol].Enabled = false;
            }
        }

        /*This function returns a string that indicates which player is currently playing*/
        private string getWhichColorIsPlayingNow()
        {
            return string.Format("Othello - {0}'s Turn", m_CurrentPlayerPlaying == ePlayers.First ? "RED" : "YELLOW");
        }

        /*This function is used in order to tell the game that the computer should play and then this function updates the board based on the choosen move of the computer*/
        private void computersTurn()
        {
            bool didComputerPlay = false;
            Ex05_Othelo.Point computersMove = null;
            PictureBox pictureBoxPressedByComputer = null;

            m_CurrentPlayerPlaying = ePlayers.Second;
            m_ourGame.TurnOf = m_CurrentPlayerPlaying;
            didComputerPlay = m_ourGame.SystemPlayComputersTurnAndNotifyIfPlayed();
            if (didComputerPlay)
            {
                computersMove = m_ourGame.LastComputersMove;
                pictureBoxPressedByComputer = m_PictureBoxMatrix[computersMove.IndexOfRow, computersMove.IndexOfCol];
                pictureBoxToFlipBasedOnCurrentsPlayerMoveAndColor(pictureBoxPressedByComputer);
            }
        }

        /*This function is repsponsible to make only valid PictureBox moves background green (valid moves for the next player)*/
        private void setPictureBoxMatrixForNextPlayer()
        {
            unMarkGreenPictureBoxs();
            m_CurrentPlayerPlaying = m_CurrentPlayerPlaying == ePlayers.First ? ePlayers.Second : ePlayers.First;
            m_ourGame.TurnOf = m_CurrentPlayerPlaying;
            this.Text = this.getWhichColorIsPlayingNow();
            findGreenCellsAndMarkPictureBoxsGreen();
        }

        /*This function makes a new Othello game with the wanted boardsize and gameMode(Computer V.S Human or Human V.S Human)*/
        public void MakeOthelloGameWithGivenSettings(int i_GameBoardSize, eGameModes i_WantedGameMode)
        {
            m_ourGame.GameMode = i_WantedGameMode;
            buildPictureBoxMatrix(i_GameBoardSize);
            putOthelloPictureBoxsOnForm();
            m_ourGame.InitializeOthelloMembers("Player1", "Player2", i_GameBoardSize);
            this.initializePictureBoxMatrix();
            m_ourGame.TurnOf = m_CurrentPlayerPlaying;
            findGreenCellsAndMarkPictureBoxsGreen();
            this.Text = this.getWhichColorIsPlayingNow();
            this.ShowDialog();
        }

        /*This function shows the score result once the game is over and then asks if we want a new round and also if we say yes then it makes a new round starts and if we say no then it ends the game*/
        private void showResultAndAskIfNewRoundWanted()
        {
            string messageForWinner = makeMessageForWinner();
            DialogResult usersChosenAction = MessageBox.Show(messageForWinner, "Othello", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (usersChosenAction == DialogResult.Yes)
            {
                this.SuspendLayout();
                m_ourGame.MakeNewRoundSettings();
                initializePictureBoxMatrix();
                findGreenCellsAndMarkPictureBoxsGreen();
                this.Text = this.getWhichColorIsPlayingNow();
                this.Refresh();
                this.ResumeLayout();
            }
            else
            {
                this.DialogResult = DialogResult.OK;
            }
        }

        /*This function is responsible to make all of the PictureBoxs not clickble,bakcgroundColor to default and that they will have no image*/
        private void setAllMatrixPictureBoxsToDisableAndControlColor()
        {
            int numberOfRowsInBoard = m_PictureBoxMatrix.GetLength(0);
            int numberOfColsInBoard = m_PictureBoxMatrix.GetLength(1);

            for (int i = 0; i < numberOfRowsInBoard; i++)
            {
                for (int j = 0; j < numberOfColsInBoard; j++)
                {
                    m_PictureBoxMatrix[i, j].Visible = true;
                    m_PictureBoxMatrix[i, j].BackColor = System.Drawing.SystemColors.Control;
                    m_PictureBoxMatrix[i, j].Enabled = false;
                    m_PictureBoxMatrix[i, j].Image = null;
                    m_PictureBoxMatrix[i, j].BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
                }
            }
        }

        /*This function finds out who won the game that return a string that says who won, how much coins he got in this match and how many rounds he won untill now(it says this information also about who lost)*/
        private string makeMessageForWinner()
        {
            int firstPlayerNumOfCoins = m_ourGame.GetAmountOfCoinsOfWantedPlayer(ePlayers.First);
            int secondPlayerNumOfCoins = m_ourGame.GetAmountOfCoinsOfWantedPlayer(ePlayers.Second);
            int firstPlayerNumOfRoundsWon = m_ourGame.NumOfWinsOfFirstPlayer;
            int secondPlayerNumOfRoundsWon = m_ourGame.NumOfWinsOfSecondPlayer;
            string messageForWinner;

            if (firstPlayerNumOfCoins > secondPlayerNumOfCoins)
            {
                messageForWinner = string.Format("{0} Won!! ({1}/{2}) ({3}/{4})\nWould you like another round?", "Red", firstPlayerNumOfCoins, secondPlayerNumOfCoins, firstPlayerNumOfRoundsWon + 1, secondPlayerNumOfRoundsWon);
            }
            else if(secondPlayerNumOfCoins > firstPlayerNumOfCoins)
            {
                messageForWinner = string.Format("{0} Won!! ({1}/{2}) ({3}/{4})\nWould you like another round?", "Yellow", secondPlayerNumOfCoins, firstPlayerNumOfCoins, secondPlayerNumOfRoundsWon + 1, firstPlayerNumOfRoundsWon);
            }
            else
            {
                messageForWinner = string.Format("It is a tie!!\nWould you like another round?");
            }

            return messageForWinner;
        }

        /*This function makes a new PictureBox with the seetings that are needed*/
        private PictureBox createPictureBox(int i_XIndex, int i_YIndex)
        {
            PictureBox newPictureBox = new PictureBox();

            newPictureBox.Name = string.Format("pictureBox{0}ON{1}", i_XIndex, i_YIndex);
            newPictureBox.Size = new System.Drawing.Size(45, 45);
            newPictureBox.TabIndex = 0;
            newPictureBox.TabStop = false;
            newPictureBox.Visible = true;
            newPictureBox.BackColor = System.Drawing.SystemColors.Control;
            newPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            newPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            newPictureBox.Enabled = false;
            newPictureBox.Anchor = (System.Windows.Forms.AnchorStyles)System.Windows.Forms.AnchorStyles.None;

            return newPictureBox;
        }
    }
}
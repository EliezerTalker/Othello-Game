﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace UserInterfaceUtils
{
    internal class Program
    {
        public static void Main()
        {
           UIManager m_UiManager = new UIManager();

           m_UiManager.StartOthelloGame();
        }
    }
}

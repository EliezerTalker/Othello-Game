﻿namespace UserInterfaceUtils
{
    public partial class GameSettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonBoardSize = new System.Windows.Forms.Button();
            this.buttonPlayerVSPc = new System.Windows.Forms.Button();
            this.buttonPlayerVsPlayer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonBoardSize
            // 
            this.buttonBoardSize.Location = new System.Drawing.Point(23, 26);
            this.buttonBoardSize.Name = "buttonBoardSize";
            this.buttonBoardSize.Size = new System.Drawing.Size(409, 43);
            this.buttonBoardSize.TabIndex = 0;
            this.buttonBoardSize.Text = "Board Size : 6x6 (click to increase)";
            this.buttonBoardSize.UseVisualStyleBackColor = true;
            this.buttonBoardSize.Click += new System.EventHandler(this.buttonBoardSize_Click);
            // 
            // buttonPlayerVSPc
            // 
            this.buttonPlayerVSPc.Location = new System.Drawing.Point(23, 90);
            this.buttonPlayerVSPc.Name = "buttonPlayerVSPc";
            this.buttonPlayerVSPc.Size = new System.Drawing.Size(200, 43);
            this.buttonPlayerVSPc.TabIndex = 1;
            this.buttonPlayerVSPc.Text = "Play against the\r\n computer";
            this.buttonPlayerVSPc.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonPlayerVSPc.UseVisualStyleBackColor = true;
            this.buttonPlayerVSPc.Click += new System.EventHandler(this.buttonPlayerVSPc_Click);
            // 
            // buttonPlayerVsPlayer
            // 
            this.buttonPlayerVsPlayer.Location = new System.Drawing.Point(229, 90);
            this.buttonPlayerVsPlayer.Name = "buttonPlayerVsPlayer";
            this.buttonPlayerVsPlayer.Size = new System.Drawing.Size(203, 43);
            this.buttonPlayerVsPlayer.TabIndex = 2;
            this.buttonPlayerVsPlayer.Text = "Play against your friend";
            this.buttonPlayerVsPlayer.UseVisualStyleBackColor = true;
            this.buttonPlayerVsPlayer.Click += new System.EventHandler(this.buttonPlayerVsPlayer_Click);
            // 
            // GameSettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 164);
            this.Controls.Add(this.buttonPlayerVsPlayer);
            this.Controls.Add(this.buttonPlayerVSPc);
            this.Controls.Add(this.buttonBoardSize);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GameSettingsForm";
            this.ShowIcon = false;
            this.Text = "Othello - Game  Settings";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonBoardSize;
        private System.Windows.Forms.Button buttonPlayerVSPc;
        private System.Windows.Forms.Button buttonPlayerVsPlayer;
    }
}
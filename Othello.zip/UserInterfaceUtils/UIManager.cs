﻿using System;
using System.Collections.Generic;
using System.Text;
using Ex05_Othelo;

namespace UserInterfaceUtils
{
    internal class UIManager
    {
        private GameSettingsForm m_GameSettingsForm;
        private GameForm m_GameForm;

        public UIManager()
        {
            m_GameSettingsForm = new GameSettingsForm();
            m_GameForm = new GameForm();
        }

        /*This function is responsible to first show the setting form of the game and once the seetings are chosen it activates the game form with the choosen settings*/
        public void StartOthelloGame()
        {
            int wantedGameBoardSize;
            eGameModes wantedGameMode;

            m_GameSettingsForm.ShowGameSettingsForm();
            wantedGameBoardSize = m_GameSettingsForm.CurrentBoardSize;
            wantedGameMode = m_GameSettingsForm.ChosenGameMode;
            m_GameForm.MakeOthelloGameWithGivenSettings(wantedGameBoardSize, wantedGameMode);
        }
    }
}

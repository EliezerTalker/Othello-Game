﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
     public class OthelloGame
    {
        private int m_NumOfWinsOfFirstPlayer = 0;
        private int m_NumOfWinsOfSecondPlayer = 0;
        private Player m_FirstPlayer;
        private Player m_SecondPlayer;
        private GameBoard m_OthelloBoard;
        private Calculator m_TurnInfo;
        private ePlayers m_TurnOf = ePlayers.First;
        private eGameModes m_GameMode = eGameModes.HumanVsHuman;
        private Point m_LastComputersMove = new Point();
        private bool m_DidFirstPlayerPlay = true;
        private bool m_DidSecondPlayerPlay = true;

        public Point LastComputersMove
        {
            get
            {
                return m_LastComputersMove;
            }
        }

        public int NumOfWinsOfFirstPlayer
        {
            get
            {
                return m_NumOfWinsOfFirstPlayer;
            }

            set
            {
                m_NumOfWinsOfFirstPlayer = value;
            }
        }

        public int NumOfWinsOfSecondPlayer
        {
            get
            {
                return m_NumOfWinsOfSecondPlayer;
            }

            set
            {
                m_NumOfWinsOfSecondPlayer = value;
            }
        }

        public eGameModes GameMode
        {
            get
            {
                return m_GameMode;
            }

            set
            {
                m_GameMode = value;
            }
        }

        public ePlayers TurnOf
        {
            get
            {
                return m_TurnOf;
            }

            set
            {
                m_TurnOf = value;
            }
        }

        /*This function above uses this functin in order to set the value the the OthelloGame class members*/
        public void InitializeOthelloMembers(string i_FirstPlayerName, string i_SecondPlayerName, int i_SizeOfBoard)
        {
            m_FirstPlayer = new Player();
            m_SecondPlayer = new Player();
            m_FirstPlayer.Name = i_FirstPlayerName;
            m_FirstPlayer.CoinColor = eColor.Black;
            m_FirstPlayer.TypeOfPlayer = ePlayerMode.HumanPlayer;
            m_SecondPlayer.Name = i_SecondPlayerName;
            m_SecondPlayer.CoinColor = eColor.White;

            if (m_GameMode == eGameModes.HumanVsHuman)
            {
                m_SecondPlayer.TypeOfPlayer = ePlayerMode.HumanPlayer;
            }

            if (m_GameMode == eGameModes.HumanVsComputer)
            {
                m_SecondPlayer.TypeOfPlayer = ePlayerMode.ComputerPlayer;
            }

            m_OthelloBoard = new GameBoard();
            m_OthelloBoard.CreateGameBoard(i_SizeOfBoard);
            m_TurnInfo = new Calculator();
            m_TurnOf = ePlayers.First;
            boardInitializer();
        }

        private void boardInitializer()
        {
            int boardSize;
            int firstLocation;
            int secondLocation;

            boardSize = m_OthelloBoard.getBoardMatrixSize();
            firstLocation = (boardSize / 2) - 1;
            secondLocation = boardSize / 2;
            m_OthelloBoard.UpdateCord(m_OthelloBoard.getCellFromIndex(firstLocation, firstLocation).XYCord, eColor.White);
            m_OthelloBoard.UpdateCord(m_OthelloBoard.getCellFromIndex(firstLocation, secondLocation).XYCord, eColor.Black);
            m_OthelloBoard.UpdateCord(m_OthelloBoard.getCellFromIndex(secondLocation, firstLocation).XYCord, eColor.Black);
            m_OthelloBoard.UpdateCord(m_OthelloBoard.getCellFromIndex(secondLocation, secondLocation).XYCord, eColor.White);
        }

        public void MakeNewRoundSettings()
        {
            m_OthelloBoard.InitializeBoard();
            m_TurnInfo.IntializeData();
            this.boardInitializer();
            if (m_FirstPlayer.NumOfcoins > m_SecondPlayer.NumOfcoins)
            {
                m_NumOfWinsOfFirstPlayer++;
            }
            else if (m_SecondPlayer.NumOfcoins > m_FirstPlayer.NumOfcoins)
            {
                m_NumOfWinsOfSecondPlayer++;
            }

            m_FirstPlayer.NumOfcoins = 2;
            m_SecondPlayer.NumOfcoins = 2;
            m_TurnOf = ePlayers.First;
        }

        public int GetAmountOfCoinsOfWantedPlayer(ePlayers i_WhichPlayer)
        {
            int finalCoinCountForWantedPlayer;

            if (i_WhichPlayer == ePlayers.First)
            {
                finalCoinCountForWantedPlayer = m_FirstPlayer.NumOfcoins;
            }
            else
            {
                finalCoinCountForWantedPlayer = m_SecondPlayer.NumOfcoins;
            }

            return finalCoinCountForWantedPlayer;
        }

        /*This function gets a index of a move in m_CoinsToFlipPerMove and flips all the coins there and also the choosen move cell */
        private void updateCoinsToFlip(int i_IndexOfMove, eColor i_WantedColor)
        {
            int numOfCoinsToFlip;
            Cell cellToUpdate;

            numOfCoinsToFlip = m_TurnInfo.GetNumOfCellsToFlip(i_IndexOfMove);

            for (int i = 0; i < numOfCoinsToFlip; i++)
            {
                cellToUpdate = m_TurnInfo.GetSpecificCellFlip(i_IndexOfMove, i);
                m_OthelloBoard.UpdateCord(cellToUpdate.XYCord, i_WantedColor);
            }

            cellToUpdate = m_TurnInfo.GetSpecificCellMove(i_IndexOfMove);
            m_OthelloBoard.UpdateCord(cellToUpdate.XYCord, i_WantedColor);
        }

        public bool SystemPlayComputersTurnAndNotifyIfPlayed()
        {
            Random randomMove = new Random();
            Player chosenPlayer = m_SecondPlayer;
            Player otherPlayer = m_FirstPlayer;
            eColor computerPlayerColor = eColor.White;
            int numOfValidMoves = 0;
            int indexOfMove = -1;
            int numOfCoinsToFlip;
            
            m_TurnInfo.IntializeData();
            m_TurnInfo.FindAllValidMoves(m_OthelloBoard, computerPlayerColor);
            numOfValidMoves = m_TurnInfo.NumOfValidMoves;
            changeStateOfDidCurrentPlayerPlay(ePlayers.Second, false);
            if (numOfValidMoves != 0)
            {
                changeStateOfDidCurrentPlayerPlay(ePlayers.Second, true);
                indexOfMove = randomMove.Next(0, numOfValidMoves);
                numOfCoinsToFlip = m_TurnInfo.GetNumOfCellsToFlip(indexOfMove);
                updateCoinsToFlip(indexOfMove, computerPlayerColor);
                chosenPlayer.NumOfcoins = chosenPlayer.NumOfcoins + numOfCoinsToFlip + 1;
                otherPlayer.NumOfcoins -= numOfCoinsToFlip;
                m_LastComputersMove = m_TurnInfo.GetSpecificCellMove(indexOfMove).XYCord;
            }

            m_TurnOf = ePlayers.First;

            return m_DidSecondPlayerPlay;
        }

        public bool PlayChosenPlayersTurnPlayerTurn(ePlayers i_WhichPlayer, int i_XCoordMove, int i_YCoordMove)
        {   
            Player chosenPlayer = m_FirstPlayer;
            Player opponentPlayer = m_SecondPlayer;
            eColor chosenPlayerColor = eColor.Black;
            bool didChosenPlayerPlay = false;
            int numOfValidMoves = 0;
            int indexOfMove = -1;
            int numOfCoinsToFlip;

            m_TurnOf = ePlayers.Second;
            if (i_WhichPlayer == ePlayers.Second)
            {
                chosenPlayer = m_SecondPlayer;
                opponentPlayer = m_FirstPlayer;
                chosenPlayerColor = eColor.White;
                m_TurnOf = ePlayers.First;
            }

            m_TurnInfo.IntializeData();
            m_TurnInfo.FindAllValidMoves(m_OthelloBoard, chosenPlayerColor);
            numOfValidMoves = m_TurnInfo.NumOfValidMoves;
            changeStateOfDidCurrentPlayerPlay(i_WhichPlayer, false);
            if (numOfValidMoves != 0)
            {
                indexOfMove = m_TurnInfo.GetIndexOfGivenMove(i_XCoordMove, i_YCoordMove);
                if (indexOfMove != -1)
                {
                    changeStateOfDidCurrentPlayerPlay(i_WhichPlayer, true);
                    numOfCoinsToFlip = m_TurnInfo.GetNumOfCellsToFlip(indexOfMove);
                    updateCoinsToFlip(indexOfMove, chosenPlayerColor);
                    chosenPlayer.NumOfcoins = chosenPlayer.NumOfcoins + numOfCoinsToFlip + 1;
                    opponentPlayer.NumOfcoins -= numOfCoinsToFlip;
                    didChosenPlayerPlay = true;
                }
            }

            return didChosenPlayerPlay;
        }

        public List<Cell> GetCurrentsPlayerLegalMoves()
        {
            Player chosenPlayer = m_FirstPlayer;
            eColor chosenPlayerColor = eColor.Black;
            List<Cell> currentsPlayerLegalMoves = new List<Cell>();
            int numOfValidMoves = 0;

            if (m_TurnOf == ePlayers.Second)
            {
                chosenPlayer = m_SecondPlayer;
                chosenPlayerColor = eColor.White;
            }

            m_TurnInfo.IntializeData();
            m_TurnInfo.FindAllValidMoves(m_OthelloBoard, chosenPlayerColor);
            numOfValidMoves = m_TurnInfo.NumOfValidMoves;
            for (int i = 0; i < numOfValidMoves; i++)
            {
                currentsPlayerLegalMoves.Add(m_TurnInfo.GetSpecificCellMove(i));
            }

            return currentsPlayerLegalMoves;
        }

        public List<Cell> GetCellsToFlipForCurrentMove(int i_XCoordMove, int i_YCoordMove)
        {
            int indexOfMove = -1;
            int amountOfCellsToFlip;
            List<Cell> cellsToFlip = new List<Cell>();

            indexOfMove = m_TurnInfo.GetIndexOfGivenMove(i_XCoordMove, i_YCoordMove);
            amountOfCellsToFlip = m_TurnInfo.GetNumOfCellsToFlip(indexOfMove);
            for (int i = 0; i < amountOfCellsToFlip; i++)
            {
                cellsToFlip.Add(m_TurnInfo.GetSpecificCellFlip(indexOfMove, i));
            }

            cellsToFlip.Add(m_TurnInfo.GetSpecificCellMove(indexOfMove));

            return cellsToFlip;
        }

        public void ResetPreviousCalculatedMoves()
        {
            m_TurnInfo.IntializeData();
        }

        public List<Cell> GetInitializePositionCells()
        {
            int boardSize;
            int firstLocation;
            int secondLocation;
            List<Cell> positionOfCellsToReturn = new List<Cell>();

            boardSize = m_OthelloBoard.getBoardMatrixSize();
            firstLocation = (boardSize / 2) - 1;
            secondLocation = boardSize / 2;
            positionOfCellsToReturn.Add(m_OthelloBoard.getCellFromIndex(firstLocation, firstLocation));
            positionOfCellsToReturn.Add(m_OthelloBoard.getCellFromIndex(firstLocation, secondLocation));
            positionOfCellsToReturn.Add(m_OthelloBoard.getCellFromIndex(secondLocation, firstLocation));
            positionOfCellsToReturn.Add(m_OthelloBoard.getCellFromIndex(secondLocation, secondLocation));

            return positionOfCellsToReturn;
        }

        public bool IsOthelloGameOver()
        {
            return !(m_DidFirstPlayerPlay || m_DidSecondPlayerPlay);
        }

        private void changeStateOfDidCurrentPlayerPlay(ePlayers i_CurrentPlayer, bool i_WantedState)
        {
            if(i_CurrentPlayer == ePlayers.First)
            {
                m_DidFirstPlayerPlay = i_WantedState;
            }
           
            if(i_CurrentPlayer == ePlayers.Second)
            {
                m_DidSecondPlayerPlay = i_WantedState;
            }
        }
    }
}

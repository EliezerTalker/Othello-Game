﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
    public enum ePlayers
    {
        First,
        Second
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
    using System.Collections.Generic;

    internal class Calculator
    {
        private const int k_InitSize = 12;
        private List<Cell> m_ValidMoves;
        private List<List<Cell>> m_CoinsToFlipPerMove;
        private int m_IndexInLists = 0;

        /*This is the constructor of the class and is allocates 12 spaces for each List type in the class*/
        internal Calculator()
        {
            m_ValidMoves = new List<Cell>(k_InitSize);
            m_CoinsToFlipPerMove = new List<List<Cell>>(k_InitSize);
        }

        /*This function  empty's both the List type members in the class and sets and member m_IndexInLists to zero*/
        internal void IntializeData()
        {
            for (int i = m_IndexInLists - 1; i >= 0; i--)
            {
                m_ValidMoves.RemoveAt(i);
                m_CoinsToFlipPerMove.RemoveAt(i);
            }

            m_IndexInLists = 0;
        }

        /*This function tells us how many othello moves were calculated and stored in the member m_ValidMoves*/
        internal int NumOfValidMoves
        {
            get
            {
                return m_ValidMoves.Count;
            }
        }

        /*This function acpects to get a index of a move in m_ValidMoves and then tells us how many coins will flip */
        internal int GetNumOfCellsToFlip(int i_IndexOfMove)
        {
            return m_CoinsToFlipPerMove[i_IndexOfMove].Count;
        }

        /*This function gives us a wanted cell from the list m_ValidMoves*/
        internal Cell GetSpecificCellMove(int i_Index)
        {
            return m_ValidMoves[i_Index];
        }

        /*This function gets a index of a othello move in m_ValidMoves and a index inside the list in m_CoinsToFlipPerMove and returns the Cell to flip */
        internal Cell GetSpecificCellFlip(int i_IndexMove, int i_IndexToFlip)
        {
            return m_CoinsToFlipPerMove[i_IndexMove][i_IndexToFlip];
        }

        /*This function gets a othello move and if its in the list m_ValidMoves it return its index otherwise it returns -1*/
        internal int GetIndexOfGivenMove(int i_XCoordMove, int i_YCoordMove)
        {
            int row = i_XCoordMove;
            int column = i_YCoordMove;
            int numOfValidMoves = m_ValidMoves.Count;
            int indexOfMove = -1;

            for (int i = 0; i < numOfValidMoves; i++)
            {
                if (m_ValidMoves[i].XYCord.IndexOfRow == row)
                {
                    if (m_ValidMoves[i].XYCord.IndexOfCol == column)
                    {
                        indexOfMove = i;
                        break;
                    }
                }
            }

            return indexOfMove;
        }

        /*This function checks is a give cordinate is a valid othello move and if it is it puts in m_ValidMoves and the coins that will flip in m_CoinsToFlipPerMove (will be at same index in both Lists)
          PLEASE NOTE : THIS FUNCTION IS A BIT LONG ONLY BECAUSE IT HAS ALOT OF PARAMETERS BUT IN THE FORLOOP ITSELF WE DO CALL OTHER FUNCTIONS AS EXCPECTED FROM US*/
        internal bool FindValidRouth(GameBoard i_GamesBoard, eColor i_CurrentPlayerColor, int i_XCord, int i_YCord, eDirection i_XDirection, eDirection i_YDirection)
        {
            bool isValidSequence = false;
            eColor colorInIndex;
            bool didOpponentColorappear = false;
            int countSquaresToFlip = 0;
            int column = i_YCord + (int)i_YDirection;
            int sizeOfBoard = i_GamesBoard.getBoardMatrixSize();
            eColor opponentСolor = getOpponentCoinСolor(i_CurrentPlayerColor);

            for (int row = i_XCord + (int)i_XDirection; row < sizeOfBoard && row >= 0 && column < sizeOfBoard && column >= 0; row += (int)i_XDirection)
            {
                colorInIndex = i_GamesBoard.GetCordData(i_GamesBoard.getCellFromIndex(row, column).XYCord);
                if (colorInIndex == i_CurrentPlayerColor)
                {
                    if (didOpponentColorappear)
                    {
                        isValidSequence = true;
                    }

                    break;
                }

                if (colorInIndex == opponentСolor)
                {
                    didOpponentColorappear = true;
                    addCellToFlip(i_GamesBoard, row, column, ref countSquaresToFlip);
                }

                if (colorInIndex == eColor.Green)
                {
                    break;
                }

                column += (int)i_YDirection;
            }

            if (!isValidSequence)
            {
                removeUnecessaryAddedCoinsToFlip(countSquaresToFlip);
            }

            return isValidSequence;
        }

        /*This function uses the function above in order to find all of the llegal othello moves and each time if find one it puts it in the Lists in the class and then increments m_IndexInLists*/
        internal void FindAllValidMoves(GameBoard i_GamesBoard, eColor i_CurrentPlayerColor)
        {
            int sizeOfBoard = i_GamesBoard.getBoardMatrixSize();
            bool isCurrentMoveValid;

            for (int i = 0; i < sizeOfBoard; i++)
            {
                for (int j = 0; j < sizeOfBoard; j++)
                {
                    isCurrentMoveValid = false;
                    if (i_GamesBoard.getCellFromIndex(i, j).CellColor == eColor.Green)
                    {
                        isCurrentMoveValid = isCurrentCellAValidMove(i_GamesBoard, i_CurrentPlayerColor, i, j);
                    }

                    if (isCurrentMoveValid)
                    {
                        m_ValidMoves.Add(i_GamesBoard.getCellFromIndex(i, j));
                        m_IndexInLists++;
                    }
                }
            }
        }

        /*This function checks if a given Cell is a valid Othello move according to the players color*/
        private bool isCurrentCellAValidMove(GameBoard i_GamesBoard, eColor i_CurrentPlayerColor, int i_XCord, int i_YCord)
        {
            bool isCurrentMoveValid = false;

            for (int xDir = (int)eDirection.Left; xDir <= (int)eDirection.Right; xDir++)
            {
                for (int yDir = (int)eDirection.Up; yDir <= (int)eDirection.Down; yDir++)
                {
                    if (xDir != (int)eDirection.Stright || yDir != (int)eDirection.Stright)
                    {
                        if (FindValidRouth(i_GamesBoard, i_CurrentPlayerColor, i_XCord, i_YCord, (eDirection)xDir, (eDirection)yDir))
                        {
                            isCurrentMoveValid = true;
                        }
                    }
                }
            }

            return isCurrentMoveValid;
        }

        private void removeUnecessaryAddedCoinsToFlip(int i_NumOfSquaresToFlip)
        {
            int logiSizeOfList = 0;

            if (m_CoinsToFlipPerMove.Count > m_IndexInLists)
            {
                logiSizeOfList = m_CoinsToFlipPerMove[m_IndexInLists].Count;
            }

            for (int i = 1; i <= i_NumOfSquaresToFlip; i++)
            {
                m_CoinsToFlipPerMove[m_IndexInLists].RemoveAt(logiSizeOfList - i);
            }
        }

        /*This function gets a cell to flip and addes it to the list m_CoinsToFlipPerMove and addes one to o_AmountOfCoins */
        private void addCellToFlip(GameBoard i_GameBoard, int i_CellXCord, int i_CellYCord, ref int o_AmountOfCoins)
        {
            if (m_CoinsToFlipPerMove.Count <= m_IndexInLists)
            {
                m_CoinsToFlipPerMove.Add(new List<Cell>());
            }

            m_CoinsToFlipPerMove[m_IndexInLists].Add(i_GameBoard.getCellFromIndex(i_CellXCord, i_CellYCord));
            o_AmountOfCoins++;
        }

        private eColor getOpponentCoinСolor(eColor i_CurrentPlayerColor)
        {
            eColor opponentСolor;

            if (i_CurrentPlayerColor == eColor.White)
            {
                opponentСolor = eColor.Black;
            }
            else
            {
                opponentСolor = eColor.White;
            }

            return opponentСolor;
        }
    }
}

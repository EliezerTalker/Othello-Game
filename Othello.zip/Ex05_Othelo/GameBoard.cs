﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
    internal class GameBoard
    {
        private Cell[,] m_BoardMatrix;

        /*This function return a char X or O based on the color it got*/
        private static char convertColorToChar(eColor i_ColorToConvert)
        {
            char convertedFromColor = ' ';

            if (i_ColorToConvert == eColor.Black)
            {
                convertedFromColor = 'X';
            }

            if (i_ColorToConvert == eColor.White)
            {
                convertedFromColor = 'O';
            }

            return convertedFromColor;
        }

        internal int getBoardMatrixSize()
        {
            return m_BoardMatrix.GetLength(0);
        }

        internal Cell getCellFromIndex(int i_XCoord, int i_YCoord)
        {
            return m_BoardMatrix[i_XCoord, i_YCoord];
        }

        internal void CreateGameBoard(int i_BoardSize)
        {
            m_BoardMatrix = new Cell[i_BoardSize, i_BoardSize];
            this.buildMatrix();
        }

        private void buildMatrix()
        {
            for (int row = 0; row < m_BoardMatrix.GetLength(0); row++)
            {
                for (int column = 0; column < m_BoardMatrix.GetLength(1); column++)
                {
                    m_BoardMatrix[row, column] = new Cell(new Point(row + 1, (char)('A' + column)), eColor.Green);
                }
            }
        }

        internal void UpdateCord(Point i_PointToUpdate, eColor i_WatedColor)
        {
            m_BoardMatrix[i_PointToUpdate.IndexOfRow, i_PointToUpdate.IndexOfCol].CellColor = i_WatedColor;
        }

        internal eColor GetCordData(Point i_PointToUpdate)
        {
            return m_BoardMatrix[i_PointToUpdate.IndexOfRow, i_PointToUpdate.IndexOfCol].CellColor;
        }

        internal void InitializeBoard()
        {
            foreach (Cell cellInBoard in m_BoardMatrix)
            {
                resetCell(cellInBoard);
            }
        }

        /*This function changes a given cellls color in the board to green(which means that no coin is in this cell)*/
        private void resetCell(Cell o_cellInBoard)
        {
            o_cellInBoard.CellColor = eColor.Green;
        }
    }
}

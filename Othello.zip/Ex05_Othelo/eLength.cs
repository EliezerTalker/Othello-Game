﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
    public enum eLength
    {
        OneChar = 1,
        TwoChar = 2
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
    internal class Player
    {
        private eColor m_CoinColor;
        private ePlayerMode m_TypeOfPlayer;
        private string m_Name;
        private int m_NumOfcoins = 2;

        internal eColor CoinColor
        {
            get
            {
                return m_CoinColor;
            }

            set
            {
                m_CoinColor = value;
            }
        }

        internal ePlayerMode TypeOfPlayer
        {
            get
            {
                return m_TypeOfPlayer;
            }

            set
            {
                m_TypeOfPlayer = value;
            }
        }

        internal string Name
        {
            get
            {
                return m_Name;
            }

            set
            {
                m_Name = value;
            }
        }

        internal int NumOfcoins
        {
            get
            {
                return m_NumOfcoins;
            }

            set
            {
                m_NumOfcoins = value;
            }
        }
    }
}

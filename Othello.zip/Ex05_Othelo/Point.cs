﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
    public class Point
    {
        private int m_NumOfRow;
        private char m_NumOfCol;

        public int IndexOfRow
        {
            get
            {
                return m_NumOfRow - 1;
            }

            set
            {
                m_NumOfRow = value;
            }
        }

        public int IndexOfCol
        {
            get
            {
                return (int)m_NumOfCol - 'A';
            }

            set
            {
                m_NumOfCol = (char)value;
            }
        }

        public char ColInLayout
        {
            get
            {
                return m_NumOfCol;
            }
        }

        public int RowInLayout
        {
            get
            {
                return m_NumOfRow;
            }
        }

        public Point(int i_XCord, char i_YCord)
        {
            m_NumOfRow = i_XCord;
            m_NumOfCol = i_YCord;
        }

        public Point()
        {
        }
    }
}
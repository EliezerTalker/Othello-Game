﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
    public enum eDirection
    {
        Left = -1,
        Right = 1,
        Stright = 0,
        Up = -1,
        Down = 1,
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex05_Othelo
{
    public class Cell
    {
        private Point m_XYCord;
        private eColor m_CellColor;

        public Point XYCord
        {
            get
            {
                return m_XYCord;
            }

            set
            {
                m_XYCord = value;
            }
        }

        public eColor CellColor
        {
            get
            {
                return m_CellColor;
            }

            set
            {
                m_CellColor = value;
            }
        }

        public Cell(Point i_CellXYCord, eColor i_ColorOfCell)
        {
            m_XYCord = i_CellXYCord;
            m_CellColor = i_ColorOfCell;
        }
    }
}
